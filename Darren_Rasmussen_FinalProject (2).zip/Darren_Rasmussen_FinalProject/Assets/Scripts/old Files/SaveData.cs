﻿using UnityEngine;
using System.Collections;

public class SaveData : MonoBehaviour {

    public enum SaveType
    {
        HighScore,
        TotalCount,

    }
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
